import my_module
from my_module import sum_calculator

print(my_module.test_function())

test = my_module.Test()
test.do_something()

print(sum_calculator(1, 2, 3, 4, 5))

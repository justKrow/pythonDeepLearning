def really_important_function():
    pass


user_input = input('Type here: ')
print(user_input)

test = 'A word'.upper()
print(test)

# username = 'JOhn SmIthXX'.title().strip('x')
# print(username)

# print(dir(username))

exercise_string = 'I like puppies puppies puppies puppies'.replace(
    'puppies', 'kittens', 2)
print(exercise_string)

exercise_string = 'i like puppies'
replaced_string = exercise_string.replace('puppies', 'crows')
print(replaced_string)
test_variable = len("A word".upper().replace("A", "X"))
print(test_variable)

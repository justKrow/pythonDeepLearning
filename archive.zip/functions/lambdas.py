def a(x): return x + 1


def simple_calc(a, b): return a + b


print(a(10))

# exercise
# create a lambda function that accepts 1 integer argument
# if the integer is > 5 return hello
# otherwise return bye


def x(x): return 'hello' if x > 5 else 'bye'


print(x(10))
